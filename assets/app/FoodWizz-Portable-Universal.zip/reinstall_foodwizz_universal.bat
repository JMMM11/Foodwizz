@echo off
setlocal enabledelayedexpansion

echo ========================================
echo    FOODWIZZ - COMPLETE REINSTALLATION
echo ========================================
echo.

echo This script will completely reinstall FoodWizz from scratch.
echo This will remove any previous configuration.
echo.
set /p confirm="Continue? (Y/N): "
if /i not "%confirm%"=="Y" (
    echo Operation canceled.
    pause
    exit /b 0
)

echo.
echo [1/6] Detecting Python...

REM Detect Python (same logic as main script)
set "python_found=0"
set "python_path="

python --version >nul 2>&1
if not errorlevel 1 (
    set "python_path=python"
    set "python_found=1"
    echo ✓ Python found in PATH
    python --version
    goto :python_found
)

set "python_paths=py python3 python3.11 python3.10 python3.9 python3.8 python3.7"
for %%p in (%python_paths%) do (
    %%p --version >nul 2>&1
    if not errorlevel 1 (
        set "python_path=%%p"
        set "python_found=1"
        echo ✓ Python found: %%p
        %%p --version
        goto :python_found
    )
)

echo ❌ ERROR: Python not found
echo Install Python from https://python.org
pause
exit /b 1

:python_found
echo.
echo [2/6] Verifying project structure...

cd /d "%~dp0restaurant-inventory-python\restaurant-inventory-python"

if not exist "app.py" (
    echo ❌ ERROR: app.py not found
    pause
    exit /b 1
)

if not exist "requirements.txt" (
    echo ❌ ERROR: requirements.txt not found
    pause
    exit /b 1
)

echo ✓ Project structure verified

echo.
echo [3/6] Removing previous configuration...

REM Remove existing virtual environment
if exist "venv" (
    echo Removing previous virtual environment...
    rmdir /s /q "venv"
    echo ✓ Previous virtual environment removed
)

REM Remove existing database
if exist "restaurant_inventory.db" (
    echo Removing previous database...
    del "restaurant_inventory.db"
    echo ✓ Previous database removed
)

REM Remove temporary files
if exist "__pycache__" (
    rmdir /s /q "__pycache__"
)

echo ✓ Previous configuration removed

echo.
echo [4/6] Creating new virtual environment...

echo Creating virtual environment...
"%python_path%" -m venv venv
if errorlevel 1 (
    echo ❌ ERROR: Could not create virtual environment
    pause
    exit /b 1
)

echo ✓ Virtual environment created

echo.
echo [5/6] Installing dependencies...

echo Upgrading pip...
venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 (
    echo ⚠️  Warning: Could not upgrade pip
)

echo Installing dependencies...
venv\Scripts\pip.exe install -r requirements.txt
if errorlevel 1 (
    echo ❌ ERROR: Could not install dependencies
    echo Attempting individual installation...
    
    venv\Scripts\pip.exe install flask
    venv\Scripts\pip.exe install firebase-admin
    venv\Scripts\pip.exe install werkzeug
    venv\Scripts\pip.exe install sqlite3
    
    if errorlevel 1 (
        echo ❌ ERROR: Critical dependencies could not be installed
        pause
        exit /b 1
    )
)

echo ✓ Dependencies installed

echo.
echo [6/6] Creating initial database...

venv\Scripts\python.exe -c "import sqlite3; conn = sqlite3.connect('restaurant_inventory.db'); conn.close()"
echo ✓ Initial database created

echo.
echo ========================================
echo    REINSTALLATION COMPLETED
echo ========================================
echo.
echo ✓ FoodWizz has been completely reinstalled
echo ✓ Virtual environment created
echo ✓ Dependencies installed
echo ✓ Database initialized
echo.
echo To start the application:
echo - Run: start_foodwizz_universal.bat
echo - Or use the desktop shortcut
echo.
pause
