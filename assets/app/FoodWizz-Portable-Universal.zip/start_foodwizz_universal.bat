@echo off
setlocal enabledelayedexpansion

echo ========================================
echo    FOODWIZZ - UNIVERSAL PORTABLE SYSTEM
echo ========================================
echo.

REM Detect Python in common locations
set "python_found=0"
set "python_path="

echo [1/5] Detecting Python on the system...

REM Check Python in PATH
python --version >nul 2>&1
if not errorlevel 1 (
    set "python_path=python"
    set "python_found=1"
    echo ✓ Python found in PATH
    python --version
    goto :python_found
)

REM Check common Windows commands
set "python_paths=py python3 python3.11 python3.10 python3.9 python3.8 python3.7"
for %%p in (%python_paths%) do (
    %%p --version >nul 2>&1
    if not errorlevel 1 (
        set "python_path=%%p"
        set "python_found=1"
        echo ✓ Python found: %%p
        %%p --version
        goto :python_found
    )
)

REM Check common install locations
set "install_paths=C:\Python311\python.exe C:\Python310\python.exe C:\Python39\python.exe C:\Python38\python.exe C:\Python37\python.exe C:\Program Files\Python311\python.exe C:\Program Files\Python310\python.exe C:\Program Files\Python39\python.exe C:\Program Files\Python38\python.exe C:\Program Files\Python37\python.exe C:\Program Files (x86)\Python311\python.exe C:\Program Files (x86)\Python310\python.exe C:\Program Files (x86)\Python39\python.exe C:\Program Files (x86)\Python38\python.exe C:\Program Files (x86)\Python37\python.exe"
for %%p in (%install_paths%) do (
    if exist "%%p" (
        set "python_path=%%p"
        set "python_found=1"
        echo ✓ Python found at: %%p
        "%%p" --version
        goto :python_found
    )
)

REM Python not found
echo.
echo ❌ ERROR: Python not found
echo.
echo Python must be installed to run FoodWizz.
echo.
echo Options to install Python:
echo 1. Download from: https://python.org
echo 2. During installation, check "Add Python to PATH"
echo 3. Restart your computer after installation
echo.
echo Locations checked:
echo - System PATH
echo - Commands: py, python, python3, python3.11, python3.10, etc.
echo - Common install folders
echo.
pause
exit /b 1

:python_found
echo.
echo [2/5] Verifying project structure...

REM Change to project directory
cd /d "%~dp0restaurant-inventory-python\restaurant-inventory-python"

REM Check essential files
if not exist "app.py" (
    echo ❌ ERROR: app.py not found
    echo Make sure to run this script from the FoodWizz project root
    pause
    exit /b 1
)

if not exist "requirements.txt" (
    echo ❌ ERROR: requirements.txt not found
    echo Make sure to run this script from the FoodWizz project root
    pause
    exit /b 1
)

echo ✓ Project structure verified

echo.
echo [3/5] Setting up virtual environment...

REM Check if virtual environment exists
if not exist "venv" (
    echo Creating new virtual environment...
    "%python_path%" -m venv venv
    if errorlevel 1 (
        echo ❌ ERROR: Could not create virtual environment
        echo Possible causes:
        echo - Insufficient permissions
        echo - Not enough disk space
        echo - Corrupt Python installation
        pause
        exit /b 1
    )
    echo ✓ Virtual environment created
) else (
    echo ✓ Existing virtual environment found
)

REM Verify virtual environment integrity
if not exist "venv\Scripts\python.exe" (
    echo ❌ ERROR: Virtual environment is corrupted
    echo Deleting corrupted virtual environment...
    rmdir /s /q "venv"
    echo Creating new virtual environment...
    "%python_path%" -m venv venv
    if errorlevel 1 (
        echo ❌ ERROR: Could not recreate virtual environment
        pause
        exit /b 1
    )
)

echo ✓ Virtual environment verified

echo.
echo [4/5] Installing dependencies...

REM Upgrade pip
echo Upgrading pip...
venv\Scripts\python.exe -m pip install --upgrade pip
if errorlevel 1 (
    echo ⚠️  Warning: Could not upgrade pip, continuing...
)

REM Install dependencies
echo Installing dependencies from requirements.txt...
venv\Scripts\pip.exe install -r requirements.txt
if errorlevel 1 (
    echo ❌ ERROR: Could not install dependencies
    echo Possible causes:
    echo - No internet connection
    echo - Incompatible dependencies
    echo - Not enough disk space
    echo.
    echo Attempting to install critical dependencies individually...
    
    REM Install critical dependencies
    venv\Scripts\pip.exe install flask
    venv\Scripts\pip.exe install firebase-admin
    venv\Scripts\pip.exe install werkzeug
    
    if errorlevel 1 (
        echo ❌ ERROR: Could not install critical dependencies
        pause
        exit /b 1
    )
    echo ✓ Critical dependencies installed
) else (
    echo ✓ All dependencies installed successfully
)

REM Create database if it doesn't exist
if not exist "restaurant_inventory.db" (
    echo Creating initial database...
    venv\Scripts\python.exe -c "import sqlite3; conn = sqlite3.connect('restaurant_inventory.db'); conn.close()"
    echo ✓ Database created
)

echo.
echo [5/5] Starting application...

REM Create desktop shortcut
set "desktop=%USERPROFILE%\Desktop"
set "shortcut=%desktop%\FoodWizz.lnk"
if not exist "%shortcut%" (
    echo Creating desktop shortcut...
    powershell -Command "$WshShell = New-Object -comObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%shortcut%'); $Shortcut.TargetPath = '%~dp0start_foodwizz_universal.bat'; $Shortcut.WorkingDirectory = '%~dp0'; $Shortcut.Description = 'FoodWizz - Restaurant Inventory System'; $Shortcut.Save()" >nul 2>&1
    echo ✓ Shortcut created
)

REM Launch application
echo Starting FoodWizz...
start /b "" venv\Scripts\python.exe app.py

REM Wait for app to initialize
timeout /t 3 /nobreak >nul

REM Open browser
start http://localhost:5000

echo.
echo ========================================
echo    FOODWIZZ STARTED SUCCESSFULLY
echo ========================================
echo.
echo ✓ Application is running in the background
echo ✓ Opened automatically in your browser
echo ✓ Desktop shortcut created
echo.
echo To access the application:
echo http://localhost:5000
echo.
echo To stop the application:
echo - Run: stop_foodwizz_universal.bat
echo - Or close all browser windows
echo.
echo You can now close this window.
echo.
timeout /t 5 /nobreak >nul
