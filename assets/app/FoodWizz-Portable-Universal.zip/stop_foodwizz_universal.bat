@echo off
echo ========================================
echo    FOODWIZZ - STOPPING APPLICATION
echo ========================================
echo.

echo [1/3] Searching for FoodWizz processes...

REM Find Python processes running app.py
set "processes_found=0"

for /f "tokens=2" %%i in ('tasklist /fi "imagename eq python.exe" /fo csv 2^>nul ^| findstr "python.exe"') do (
    echo Python process found: %%i
    set "processes_found=1"
)

REM Find processes using port 5000
for /f "tokens=5" %%i in ('netstat -ano 2^>nul ^| findstr ":5000"') do (
    echo Process on port 5000: %%i
    taskkill /pid %%i /f >nul 2>&1
    if not errorlevel 1 (
        echo ✓ Process %%i terminated
    )
)

echo.
echo [2/3] Terminating related processes...

REM Terminate Python processes related to Flask
for /f "tokens=2" %%i in ('tasklist /fi "imagename eq python.exe" /fo csv 2^>nul ^| findstr "python.exe"') do (
    echo Terminating Python process: %%i
    taskkill /pid %%i /f >nul 2>&1
    if not errorlevel 1 (
        echo ✓ Process %%i terminated
    )
)

REM Find and terminate specific FoodWizz processes
for /f "tokens=2" %%i in ('wmic process where "name='python.exe' and commandline like '%%app.py%%'" get processid /value 2^>nul ^| findstr "ProcessId"') do (
    echo Terminating FoodWizz process: %%i
    taskkill /pid %%i /f >nul 2>&1
    if not errorlevel 1 (
        echo ✓ FoodWizz process terminated
    )
)

echo.
echo [3/3] Verifying application has stopped...

REM Check that port 5000 is free
netstat -ano 2>nul | findstr ":5000" >nul
if errorlevel 1 (
    echo ✓ Port 5000 is free
) else (
    echo ⚠️  Warning: Processes still using port 5000
)

REM Check for remaining Python processes
tasklist /fi "imagename eq python.exe" /fo csv 2>nul | findstr "python.exe" >nul
if errorlevel 1 (
    echo ✓ No Python processes running
) else (
    echo ⚠️  Warning: Some Python processes are still running
    echo If any are FoodWizz, terminate them manually via Task Manager
)

echo.
echo ========================================
echo    APPLICATION STOPPED
echo ========================================
echo.
echo ✓ FoodWizz has been stopped
echo ✓ Port 5000 is free
echo.
echo You can now close this window.
echo.
echo To restart FoodWizz:
echo - Run: start_foodwizz_universal.bat
echo - Or use the desktop shortcut
echo.
pause