@echo off
:menu
cls
echo ========================================
echo        FOODWIZZ - MAIN MENU
echo ========================================
echo.
echo Select an option:
echo.
echo 1. Start FoodWizz (Recommended)
echo 2. Stop FoodWizz
echo 3. Reinstall FoodWizz (If issues occur)
echo 4. Create Universal Portable ZIP
echo 5. View Instructions
echo 6. Exit
echo.
set /p choice="Enter your choice (1-6): "

if "%choice%"=="1" goto :start
if "%choice%"=="2" goto :stop
if "%choice%"=="3" goto :reinstall
if "%choice%"=="4" goto :create_zip
if "%choice%"=="5" goto :instructions
if "%choice%"=="6" goto :exit
echo Invalid option. Please try again.
pause
goto :menu

:start
echo.
echo Starting FoodWizz...
call start_foodwizz_universal.bat
goto :end

:stop
echo.
echo Stopping FoodWizz...
call stop_foodwizz_universal.bat
goto :end

:reinstall
echo.
echo Reinstalling FoodWizz...
call reinstall_foodwizz_universal.bat
goto :end

:create_zip
echo.
echo Creating Universal Portable ZIP...
call crear_zip_universal.bat
goto :end

:instructions
echo.
echo Opening instructions...
if exist "README_UNIVERSAL.txt" (
    notepad "README_UNIVERSAL.txt"
) else (
    echo Instructions file not found.
    echo.
    echo QUICK INSTRUCTIONS:
    echo.
    echo 1. Run: start_foodwizz_universal.bat
    echo 2. It will automatically open at: http://localhost:5000
    echo 3. To stop: stop_foodwizz_universal.bat
    echo.
    echo REQUIREMENTS:
    echo - Python 3.7+ installed
    echo - Internet connection (first time only)
    echo.
)
pause
goto :menu

:exit
echo.
echo Exiting...
exit /b 0

:end
echo.
echo Press any key to return to the menu...
pause >nul
goto :menu
